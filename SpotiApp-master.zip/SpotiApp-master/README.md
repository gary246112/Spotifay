<h1 align="center">
SpotiApp 🎧
</h1>
<p align="center">Es una aplicación echa con angular 7 en el cual consume la Api de Spotify, Muestra los ultimos lanzamientos, tiene un buscador de artistas, tiene su propio perfil el artista con sus canciones además tiene un widget para que escuches una cancion previa.</p>

## Como Usar
Debes tener una cuenta de spotify para que puedas usar su api.
ingresa a la página "Spotify For Developers" en la seccion de "Dashboard" <a href="https://developer.spotify.com/dashboard/">Dashboard</a> 👈, logeate con tu cuenta y crea una "nueva app", Ingresa el nombre de tu app, una pequeña descripcion y selecciona que estas construyendo un website, en el segundo paso selecciona que no vas a generar ingresos con su Api, posteriormente acepta todos los terminos.
una vez que ya tengas tu app iniciada te proporcionaran un client_id y client_secret. estos te serviran para que puedas generar un token. **Ojo este token expira cada hora yo hacia la peticion para generar el token con postman** y listo. 😎

<h2 align="center">Saludos... 🤟 </h2>
